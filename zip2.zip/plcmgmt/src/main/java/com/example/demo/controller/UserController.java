package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class UserController {
	
	@Autowired
    private UserService UserService;
	

    @PostMapping("/User")
    public User saveUser(@RequestBody User User) {
       
        return UserService.saveUser(User);
    }
    

    @GetMapping("User")
    public List<User> fetchUserList() {
        //LOGGER.info("Inside fetchUserList of UserController");
        return UserService.fetchUserList();
    }
    


    @GetMapping("/User/{id}")
    public User fetchUsertById(@PathVariable("id") Long UserId)
            {
        return UserService.fetctUserById(UserId);
    }
    
    @DeleteMapping("/User/{id}")
    public String deleteUserById(@PathVariable("id") Long UserId) {
    	UserService.deleteUserById(UserId);
        return "User deleted Successfully!!";
    }
    
    @PutMapping("/User/{id}")
    public User updateUser(@PathVariable("id") Long UserId,
                                       @RequestBody User User) {
        return UserService.updateUser(UserId,User);
    }
}



