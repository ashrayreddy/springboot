package com.example.demo.service;
package com.dailycodebuffer.Springboot.tutorial.service;

import java.util.List;

import com.dailycodebuffer.Springboot.tutorial.entity.User;

public interface UserService {

	public User saveUser(User User);

	public List<User> fetchUserList();

	public User fetchUserById(Long UserId);

	public void deleteUserById(Long UserId);

	public User updateUser(Long UserId, User User);

}

public interface UserService {

}
