package com.example.demo.service;
package com.dailycodebuffer.Springboot.tutorial.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dailycodebuffer.Springboot.tutorial.entity.User;
//import com.dailycodebuffer.Springboot.tutorial.error.UserNotFoundException;
import com.dailycodebuffer.Springboot.tutorial.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository UserRepository;

    @Override
    public User saveUser(User department) {
        return UserRepository.save(User);
    }

    @Override
    public List<User> fetchUserList() {
        return UserRepository.findAll();
    }

   @Override
   public User fetchUserById(Long UserId) {
	   return UserRepository.findById(UserId).get();
   }
	
   @Override
   public void deleteUserById(Long UserId) {
	   UserRepository.deleteById(UserId);
   }


   @Override
   public User updateUser(Long UserId, User User) {
	   User depDB = UserRepository.findById(UserId).get();

       if(Objects.nonNull(User.getUserName()) &&
       !"".equalsIgnoreCase(User.getUserName())) {
           depDB.setUserName(User.getUserName());
       }

       if(Objects.nonNull(User.getUserCode()) &&
               !"".equalsIgnoreCase(User.getUserCode())) {
           depDB.setUserCode(User.getUserCode());
       }

       if(Objects.nonNull(User.getUserAddress()) &&
               !"".equalsIgnoreCase(User.getUserAddress())) {
           depDB.setUserAddress(User.getUserAddress());
       }

       return UserRepository.save(depDB);
   }

    
    

}



