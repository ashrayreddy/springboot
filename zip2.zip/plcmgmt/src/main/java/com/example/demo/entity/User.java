package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class User{
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private Long Id;
	private String Name;
	private String Type;
	private String Password;
	public User() {
		
	}
	public User(Long id, String name, String type, String password) {
		super();
		Id = id;
		Name = name;
		Type = type;
		Password = password;
	}
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	@Override
	public String toString() {
		return "User [Id=" + Id + ", Name=" + Name + ", Type=" + Type + ", Password=" + Password + "]";
	}
	
	

}
